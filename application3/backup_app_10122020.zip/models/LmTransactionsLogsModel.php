<?php
require_once 'Master.php';
class LmTransactionsLogsModel extends Master
{
	public $table = 'lm_transactions_logs';
	public $primary_key = 'id';
}
