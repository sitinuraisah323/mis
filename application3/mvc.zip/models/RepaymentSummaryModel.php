<?php
require_once 'Master.php';
class RepaymentSummaryModel extends Master
{
	public $table = 'units_repayments_summaries';
	public $primary_key = 'id';
}
