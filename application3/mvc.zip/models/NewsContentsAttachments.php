<?php
require_once 'Master.php';
class NewsContentsAttachments extends Master
{
	public $table = 'news_contents_attachments';
	public $primary_key = 'id';

}


