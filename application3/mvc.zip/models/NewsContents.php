<?php
require_once 'Master.php';
class NewsContents extends Master
{
	public $table = 'news_contents';
	public $primary_key = 'id';

}


