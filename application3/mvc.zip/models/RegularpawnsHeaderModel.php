<?php
require_once 'Master.php';
class RegularpawnsHeaderModel extends Master
{
	public $table = 'units_regularpawns_header';
	public $primary_key = 'id';

}


