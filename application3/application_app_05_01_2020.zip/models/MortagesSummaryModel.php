<?php
require_once 'Master.php';
class MortagesSummaryModel extends Master
{
	public $table = 'units_mortages_summary';
	public $primary_key = 'id';

}


