<?php
require_once 'Master.php';
class GroupsModel extends Master
{
	public $table = 'areas_group';
	public $primary_key = 'id';
}
