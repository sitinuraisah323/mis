<?php
require_once 'Master.php';
class CustomersrepairModel extends Master
{
	public $table = 'customers_history';

	public $primary_key = 'id';

}
