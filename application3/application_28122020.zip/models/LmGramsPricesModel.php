<?php
require_once 'Master.php';
class LmGramsPricesModel extends Master
{
	public $table = 'lm_grams_prices';
	public $primary_key = 'id';
}
