<?php
require_once 'Master.php';
class LmGramsModel extends Master
{
	public $table = 'lm_grams';
	public $primary_key = 'id';
}
