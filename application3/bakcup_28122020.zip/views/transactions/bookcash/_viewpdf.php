<!--begin::Modal-->
<div class="modal fade" id="modal_pdf" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <form id="form_viewpdf">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">BAP Kas Preview</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="kt-portlet__body"> 
                        <div class="row">    
                            <div class="col-md-12"> 
                                view pdf            
                            </div>
                        </div>                                            
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!--end::Modal-->