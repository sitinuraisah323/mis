<?php
require_once 'Master.php';
class LmTransactionsModel extends Master
{
	public $table = 'lm_transactions';
	public $primary_key = 'id';
}
