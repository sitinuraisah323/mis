<?php
require_once 'Master.php';
class CustomersModel extends Master
{
	public $table = 'customers';

	public $primary_key = 'id';
}
