<?php
require_once 'Master.php';
class AreasModel extends Master
{
	public $table = 'areas';
	public $primary_key = 'id';

}


