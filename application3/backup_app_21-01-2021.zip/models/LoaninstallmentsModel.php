<?php
require_once 'Master.php';
class LoaninstallmentsModel extends Master
{
	public $table = 'units_loaninstallments';

	public $primary_key = 'id';
}
